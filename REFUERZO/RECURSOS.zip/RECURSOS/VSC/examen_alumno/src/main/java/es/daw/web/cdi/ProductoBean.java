package es.daw.web.cdi;

public class ProductoBean {






    
}
